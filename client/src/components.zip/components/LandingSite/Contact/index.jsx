import { Contact } from "./Contact"

export default function ContactPage() {
  return (
    <Contact />
  )
}
